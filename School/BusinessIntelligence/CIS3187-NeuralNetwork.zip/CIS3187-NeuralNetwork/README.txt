This folder contains all the Java files used to construct the feed forward neural network, along with the data used to train and test the network, both the XOR data and titanic data. 

The full data sets used are labled ' titanic_dataset.csv' and 'XOR dataset.csv'. The data was splt accordingly into 80%/20% paritions in bot cases.The traning data of the titanic data 
set is labeled ' trainData.csv ' and the test data is labeled ' testData.csv '. For the XOR data, the training data is labeled 'xorDatasetTrain.csv' and the test data is labeled ' xorDatasetTest.csv '.

This folder also contains the obtained results from each data set; ' test.csv ' and ' train.csv 'for the titanic data set,  ' xorTest.csv ' and ' xorTrain.csv ' for the XOR data set.

Note that the obtained results might differ from those present in the report since they might have been retested at different times. The data and process is ofcourse the same and the results are still 
reliable. 